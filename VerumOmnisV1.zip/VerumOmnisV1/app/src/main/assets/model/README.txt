Drop production ONNX models here before release:
- behavioral.onnx
- voice.onnx
- image.onnx
- video.onnx
(App will run in Rules-Only Mode if these are missing.)
